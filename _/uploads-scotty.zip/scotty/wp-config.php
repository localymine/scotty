<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://codex.wordpress.org/Editing_wp-config.php

 *

 * @package WordPress

 */



// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define('DB_NAME', 'thegioip_scotty');



/** MySQL database username */

define('DB_USER', 'thegioip_scotty');



/** MySQL database password */

define('DB_PASSWORD', '#;Z46Edl=2GV');



/** MySQL hostname */

define('DB_HOST', 'localhost');



/** Database Charset to use in creating database tables. */

define('DB_CHARSET', 'utf8mb4');



/** The Database Collate type. Don't change this if in doubt. */

define('DB_COLLATE', '');



/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define('AUTH_KEY',         '?yz!X-qcI8TmLPzg!ju,Ut;9e:390KtOR4y3M<&~m~G5MRJ7S;2O[C:uM_s7qIR?');

define('SECURE_AUTH_KEY',  '+$AW9:,vM4N%X8sRG~m|WfAj4-xtuib~3yHAr&&M;4xm,q*Fh_}G+FX21|btz-g$');

define('LOGGED_IN_KEY',    'lVWCDS<?od_W^yR_EQv0KryG9#GUR)uDN/Kp4)-~+YD4>$GxVJA;m-;8!-W6<@R0');

define('NONCE_KEY',        '[FoE?w]zE3mpOGy{Aidlh.^{mRX>P1~=#5pyZ>`fIG?X$]U8fC_&{.0AQm~Cr-c.');

define('AUTH_SALT',        '6Y%&B W%O;v|x|C!t~9l}~(Xk9!0Ql|`fh}v@e>,>E32Iy0~ BhVV^,1F;(87&iN');

define('SECURE_AUTH_SALT', '.&!G pN&8/Bh}xNWN;h|dEjY7Pq+Qg/@VrFaS;>u3wQF-0&)n}hek9}eZNE!M1:%');

define('LOGGED_IN_SALT',   '50lxUX3u?X,{*}-L!l]1X57$dCfG_s@||=2Uor:)u$c&9+{ !=-L)F/%k$zm/F-(');

define('NONCE_SALT',       '<A~cOxmz;,kR|L[W]8Ggib ]dI$zZeMPVr6K3E4CrhQme+CZhE]j*%K0vsHh+v7w');



/**#@-*/



/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix  = 'wp_';



/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the Codex.

 *

 * @link https://codex.wordpress.org/Debugging_in_WordPress

 */

define('WP_DEBUG', false);



/* That's all, stop editing! Happy blogging. */



/** Absolute path to the WordPress directory. */

if ( !defined('ABSPATH') )

	define('ABSPATH', dirname(__FILE__) . '/');



/** Sets up WordPress vars and included files. */

require_once(ABSPATH . 'wp-settings.php');

